# Udyam Digital prototype — video narration

**Suggested length:** 3–4 minutes  
**Before recording:** Start the app using `start.bat` and open `http://127.0.0.1:8000`. Keep the terminal out of the recording. The example uses fictional sample data.

## 0:00–0:20 · Opening

**On screen:** Overview tab.

**Say:**  
“Small businesses often have to make multiple calls and repeat information before their services are ready. Udyam Digital proposes a simpler journey: discover the need, see an eligible quote, verify business details with consent, and track the next step. This prototype shows that journey using the synthetic data provided with our solution.”

## 0:20–0:50 · The opportunity

**On screen:** Point to the KPI cards and funnel.

**Say:**  
“The dashboard starts with the supplied sample of five thousand leads from April to June 2026. We can see how many reached each funnel stage, along with the observed activation rate, time to activate, acquisition cost, and follow-up calls. These are sample-data baselines, not a live Airtel dashboard.”

## 0:50–1:45 · Advisor and quote

**On screen:** Choose **Advisor & quote**. Leave Professional office selected, set six employees and one site, then select **Build my recommendation**.

**Say:**  
“The advisor gathers only a few business details. For this prototype, the recommendation is deliberately rule-based rather than connected to a generative AI service. It filters the supplied product catalogue by segment, city tier, business size, GSTIN requirements, and product dependencies. The price range is calculated from catalogue prices and shown with the suggested products and setup fee.”

**Optional:** Change segment to Micro retail & services and build the recommendation again.

**Say:**  
“The same flow can present a different eligible bundle for a micro business. The important point is that the system does not invent a product or price.”

## 1:45–2:30 · Consent-first KYC

**On screen:** Choose **Smart KYC**. Select GSTIN, tick the consent checkbox, and enter a GSTIN copied from `data/mock_gstin_registry.csv`.

**Say:**  
“Before lookup, the screen explains the purpose and asks for consent. The prototype checks only the supplied fictional registry. It returns a masked identifier and a small set of business details. It does not retain the lookup or accept document uploads. A production implementation would need approved registry and document-verification integrations, appropriate security controls, and a full privacy review.”

## 2:30–3:10 · Order tracker

**On screen:** Return to the generated quote and select **Continue to order**.

**Say:**  
“From the quote, we can create a temporary order reference. The tracker makes the next steps visible: KYC, order review, and installation. This is a prototype journey. It does not place a real order, collect payment, or schedule an engineer.”

## 3:10–3:35 · Human handoff and close

**On screen:** Choose **Field handoff** and show the priority queue.

**Say:**  
“Finally, the field handoff view shows a transparent way to surface leads that may need help, without showing contact details. In the proposed solution, partners and field teams can use this context to assist customers instead of competing with the digital journey.”

“This prototype turns the proposal into a testable end-to-end experience. The next step would be a controlled pilot with approved product, registry, privacy, and operational integrations.”

## Recording notes

- Read from the on-screen labels; avoid implying the prototype uses real AI or live Airtel systems.
- The default professional-office sample quote does not need a GSTIN. For a GSTIN lookup, copy an identifier from the synthetic registry CSV.
- Avoid showing raw customer identifiers in the recording. Lookup results are masked by the app.
