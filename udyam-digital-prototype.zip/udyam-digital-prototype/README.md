# Udyam Digital prototype

A self-contained, local web prototype based on the Udyam Digital solution deck and the supplied synthetic dataset. It includes:

- A lead-funnel dashboard derived from `smb_leads.csv`.
- A rule-based business advisor and quote that reads `product_catalogue.csv`.
- A consent-first GSTIN/Udyam lookup against the supplied mock registries, with masked identifiers.
- A temporary, in-memory sample order tracker.
- A transparent sample lead-priority queue that does not expose contact details.

## Requirements

- Python 3.9 or later
- A modern browser
- No third-party Python packages or internet connection required to run the application

## Run on Windows

1. Extract the project ZIP.
2. Double-click `start.bat`, or open PowerShell in this folder and run:

   ```powershell
   python server.py
   ```

3. Open <http://127.0.0.1:8000>.
4. To stop the server, press `Ctrl+C` in the terminal.

If port 8000 is in use, change `PORT` near the top of `server.py`.

## Suggested walkthrough

1. Start on **Overview** and point out the data-backed funnel and baseline metrics.
2. Open **Advisor & quote**, keep the professional-office example or try another segment, and generate a catalogue-backed quote.
3. Open **Smart KYC**, check the consent box, and look up a GSTIN or Udyam number from the supplied registry CSVs.
4. Return to the quote and continue to **Order tracker** to create a temporary sample order.
5. Finish on **Field handoff** to show an explainable priority queue with no contact details.

The narration is in [`VIDEO_SCRIPT.md`](./VIDEO_SCRIPT.md).

## Prototype boundaries

All sample businesses and identifiers in the provided dataset are fictional. The server binds to `127.0.0.1` and uses only local files. It does not call Airtel services or live registries, and does not implement an AI model, OCR/document upload, e-sign, payment, WhatsApp, authentication, or production security controls. The advisor uses deterministic rules; the order tracker is in-memory and resets when the server restarts. Lookup requires an explicit consent flag and returns masked identifiers; lookup requests are not logged or persisted.

The product quote calculates ranges from the supplied catalogue and the prototype's explicit bundle quantities. Actual catalogue rates may differ from the indicative figures in the solution deck; this prototype does not represent a commercial offer.

## Run tests

```powershell
python -m unittest discover -s tests -v
```
